import SwiftUI
import UniformTypeIdentifiers

struct RootView: View {
    @EnvironmentObject var model: AppModel
    @State private var showOpenPicker = false
    @State private var showSettings = false

    var body: some View {
        NavigationStack {
            Group {
                if let archive = model.archive {
                    DirectoryView(archive: archive, directory: archive.root, title: model.archiveName)
                        .toolbar {
                            ToolbarItem(placement: .navigationBarLeading) {
                                Button("Cerrar") { model.close() }
                            }
                        }
                } else {
                    welcome
                }
            }
        }
        .fileImporter(isPresented: $showOpenPicker, allowedContentTypes: [.data]) { result in
            switch result {
            case .success(let url): model.open(url: url)
            case .failure(let err): model.errorMessage = err.localizedDescription
            }
        }
        .sheet(isPresented: $showSettings) {
            SettingsView().environmentObject(model)
        }
        .alert("Error", isPresented: Binding(
            get: { model.errorMessage != nil },
            set: { if !$0 { model.errorMessage = nil } }
        )) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(model.errorMessage ?? "")
        }
    }

    private var welcome: some View {
        VStack(spacing: 20) {
            Spacer()
            Image(systemName: "shippingbox")
                .font(.system(size: 64))
                .foregroundStyle(.tint)
            Text("RPF Viewer")
                .font(.largeTitle.bold())
            Text("Abrí un archivo .rpf (RPF7) para ver su contenido, extraer archivos y reemplazarlos.")
                .multilineTextAlignment(.center)
                .foregroundStyle(.secondary)
                .padding(.horizontal, 32)

            Button {
                showOpenPicker = true
            } label: {
                Label("Abrir RPF", systemImage: "folder")
                    .frame(maxWidth: 240)
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)

            Button {
                showSettings = true
            } label: {
                Label(model.hasKey ? "Clave AES cargada" : "Ajustes y clave AES",
                      systemImage: model.hasKey ? "key.fill" : "gearshape")
            }
            .padding(.top, 4)
            Spacer()
        }
        .padding()
    }
}

struct SettingsView: View {
    @EnvironmentObject var model: AppModel
    @Environment(\.dismiss) private var dismiss
    @State private var showKeyPicker = false

    var body: some View {
        NavigationStack {
            Form {
                Section("Clave AES") {
                    HStack {
                        Text("Estado")
                        Spacer()
                        Text(model.hasKey ? "Cargada" : "No cargada")
                            .foregroundStyle(model.hasKey ? .green : .secondary)
                    }
                    Button("Importar clave…") { showKeyPicker = true }
                    if model.hasKey {
                        Button("Quitar clave", role: .destructive) { model.removeKey() }
                    }
                }
                Section {
                    Text("Los RPF cifrados con AES necesitan una clave de 32 bytes. Importá un archivo con los 32 bytes crudos, o un texto con 64 caracteres hexadecimales. La app no incluye ninguna clave: tenés que obtenerla de tu propia copia del juego.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
                Section("Alcance de esta versión") {
                    Label("RPF7 sin cifrar o con AES", systemImage: "checkmark.circle")
                    Label("Cifrado NG: no soportado", systemImage: "xmark.circle")
                    Label("Reemplazo: solo archivos binarios", systemImage: "info.circle")
                    Label("RPF anidados: extraelos y abrilos aparte", systemImage: "info.circle")
                }
                .font(.footnote)
            }
            .navigationTitle("Ajustes")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Listo") { dismiss() }
                }
            }
            .fileImporter(isPresented: $showKeyPicker, allowedContentTypes: [.data, .text]) { result in
                if case .success(let url) = result { model.importKey(from: url) }
            }
        }
    }
}
