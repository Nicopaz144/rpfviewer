import SwiftUI
import UniformTypeIdentifiers

// MARK: - Lista de una carpeta

struct DirectoryView: View {
    @EnvironmentObject var model: AppModel
    let archive: RPFArchive
    let directory: RPFEntry
    let title: String

    @State private var search = ""
    @State private var previewEntry: RPFEntry?
    @State private var shareItem: ShareItem?
    @State private var replaceTarget: RPFEntry?
    @State private var confirmReplace = false
    @State private var showReplacePicker = false
    @State private var busy = false

    private var children: [RPFEntry] {
        var list = archive.children(of: directory)
        if !search.isEmpty {
            list = list.filter { $0.name.localizedCaseInsensitiveContains(search) }
        }
        return list.sorted {
            if $0.isDirectory != $1.isDirectory { return $0.isDirectory }
            return $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending
        }
    }

    var body: some View {
        let _ = model.revision   // refresca la lista tras reemplazar un archivo

        List(children) { entry in
            if entry.isDirectory {
                NavigationLink {
                    DirectoryView(archive: archive, directory: entry, title: entry.name)
                } label: {
                    EntryRow(entry: entry)
                }
            } else {
                Button {
                    previewEntry = entry
                } label: {
                    EntryRow(entry: entry)
                }
                .buttonStyle(.plain)
                .swipeActions(edge: .trailing) {
                    Button("Exportar") { export(entry) }.tint(.blue)
                    if entry.kind == .binary && archive.isWritable {
                        Button("Reemplazar") {
                            replaceTarget = entry
                            confirmReplace = true
                        }.tint(.orange)
                    }
                }
                .contextMenu {
                    Button { export(entry) } label: { Label("Exportar", systemImage: "square.and.arrow.up") }
                    if entry.kind == .binary && archive.isWritable {
                        Button {
                            replaceTarget = entry
                            confirmReplace = true
                        } label: { Label("Reemplazar…", systemImage: "arrow.triangle.2.circlepath") }
                    }
                }
            }
        }
        .listStyle(.plain)
        .navigationTitle(title.isEmpty ? "/" : title)
        .navigationBarTitleDisplayMode(.inline)
        .searchable(text: $search, prompt: "Buscar en esta carpeta")
        .overlay {
            if busy { ProgressView().controlSize(.large) }
            else if children.isEmpty { Text("Carpeta vacía").foregroundStyle(.secondary) }
        }
        .sheet(item: $previewEntry) { entry in
            PreviewView(archive: archive, entry: entry) { export(entry) }
        }
        .sheet(item: $shareItem) { item in
            ShareSheet(url: item.url)
        }
        .alert("Reemplazar archivo", isPresented: $confirmReplace) {
            Button("Cancelar", role: .cancel) {}
            Button("Elegir archivo", role: .destructive) { showReplacePicker = true }
        } message: {
            Text("Esto modifica el RPF original. Te recomiendo tener una copia de seguridad antes de continuar.")
        }
        .fileImporter(isPresented: $showReplacePicker, allowedContentTypes: [.data]) { result in
            switch result {
            case .success(let url):
                if let target = replaceTarget { model.replace(target, with: url) }
            case .failure(let err):
                model.errorMessage = err.localizedDescription
            }
        }
    }

    private func export(_ entry: RPFEntry) {
        previewEntry = nil
        Task { @MainActor in
            busy = true
            await Task.yield()
            if let url = model.export(entry) {
                // pequeña espera para que se cierre la hoja de vista previa
                try? await Task.sleep(nanoseconds: 300_000_000)
                shareItem = ShareItem(url: url)
            }
            busy = false
        }
    }
}

// MARK: - Fila

struct EntryRow: View {
    let entry: RPFEntry

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon)
                .font(.title3)
                .frame(width: 28)
                .foregroundStyle(entry.isDirectory ? Color.accentColor : .secondary)
            VStack(alignment: .leading, spacing: 2) {
                Text(entry.name.isEmpty ? "(sin nombre)" : entry.name)
                    .lineLimit(1)
                    .truncationMode(.middle)
                HStack(spacing: 6) {
                    Text(subtitle)
                    if entry.kind == .resource { Tag(text: "recurso") }
                    if entry.isCompressed { Tag(text: "comprimido") }
                    if entry.isEncrypted { Tag(text: "cifrado") }
                }
                .font(.caption)
                .foregroundStyle(.secondary)
            }
            Spacer(minLength: 0)
        }
        .contentShape(Rectangle())
    }

    private var subtitle: String {
        entry.isDirectory
            ? "\(entry.childCount) elementos"
            : ByteCountFormatter.string(fromByteCount: Int64(entry.displaySize), countStyle: .file)
    }

    private var icon: String {
        if entry.isDirectory { return "folder" }
        if entry.isNestedArchive { return "shippingbox" }
        switch (entry.name as NSString).pathExtension.lowercased() {
        case "xml", "meta", "txt", "dat", "ymt", "ymap", "ytyp", "ymf": return "doc.text"
        case "dds", "png", "jpg", "ytd": return "photo"
        case "ydr", "ydd", "yft", "ydr_lod", "ybn": return "cube"
        case "awc", "rel": return "waveform"
        default: return "doc"
        }
    }
}

struct Tag: View {
    let text: String
    var body: some View {
        Text(text)
            .font(.caption2)
            .padding(.horizontal, 5)
            .padding(.vertical, 1)
            .background(Color.secondary.opacity(0.15), in: Capsule())
    }
}

// MARK: - Vista previa

struct PreviewView: View {
    @Environment(\.dismiss) private var dismiss
    let archive: RPFArchive
    let entry: RPFEntry
    let onExport: () -> Void

    @State private var loaded = false
    @State private var content = ""
    @State private var note: String?

    private static let maxPreviewBytes = 64 * 1024 * 1024

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    infoBlock
                    if let note = note {
                        Text(note).font(.footnote).foregroundStyle(.secondary)
                    }
                    if !content.isEmpty {
                        Text(content)
                            .font(.system(.caption, design: .monospaced))
                            .textSelection(.enabled)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    } else if !loaded {
                        ProgressView()
                    }
                }
                .padding()
            }
            .navigationTitle(entry.name)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cerrar") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Exportar") { onExport() }
                }
            }
        }
        .task { await load() }
    }

    private var infoBlock: some View {
        VStack(alignment: .leading, spacing: 4) {
            row("Tipo", entry.kind == .resource ? "Recurso" : "Binario")
            row("Tamaño", ByteCountFormatter.string(fromByteCount: Int64(entry.displaySize), countStyle: .file))
            row("Posición", "bloque \(entry.fileOffsetBlocks) (0x\(String(UInt64(entry.fileOffsetBlocks) * 512, radix: 16, uppercase: true)))")
            row("Comprimido", entry.isCompressed ? "Sí" : "No")
            row("Cifrado", entry.isEncrypted ? "Sí" : "No")
        }
        .font(.footnote)
    }

    private func row(_ k: String, _ v: String) -> some View {
        HStack {
            Text(k).foregroundStyle(.secondary)
            Spacer()
            Text(v)
        }
    }

    private func load() async {
        defer { loaded = true }
        if entry.displaySize > Self.maxPreviewBytes {
            note = "Archivo demasiado grande para la vista previa. Usá Exportar."
            return
        }
        await Task.yield()
        do {
            let data = try archive.extract(entry)
            if entry.kind == .resource {
                note = "Recurso mostrado tal como está guardado en el RPF (sin decodificar)."
            }
            content = Self.render(data)
        } catch {
            note = error.localizedDescription
        }
    }

    static func render(_ data: Data) -> String {
        let sample = data.prefix(4096)
        let printable = sample.filter { $0 == 9 || $0 == 10 || $0 == 13 || ($0 >= 32 && $0 < 127) || $0 >= 128 }.count
        let looksText = !sample.isEmpty && !sample.contains(0) && Double(printable) / Double(sample.count) > 0.95

        if looksText, let text = String(data: data.prefix(40_000), encoding: .utf8) {
            return text
        }
        return hexDump(data, limit: 1024)
    }

    static func hexDump(_ data: Data, limit: Int) -> String {
        let bytes = [UInt8](data.prefix(limit))
        var lines: [String] = []
        var i = 0
        while i < bytes.count {
            let chunk = Array(bytes[i..<min(i + 16, bytes.count)])
            let hex = chunk.map { String(format: "%02X", $0) }.joined(separator: " ")
            let padded = hex.padding(toLength: 47, withPad: " ", startingAt: 0)
            let ascii = String(chunk.map { $0 >= 32 && $0 < 127 ? Character(UnicodeScalar($0)) : "." })
            lines.append(String(format: "%08X  ", i) + padded + "  " + ascii)
            i += 16
        }
        return lines.joined(separator: "\n")
    }
}

// MARK: - Compartir

struct ShareItem: Identifiable {
    let id = UUID()
    let url: URL
}

struct ShareSheet: UIViewControllerRepresentable {
    let url: URL

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: [url], applicationActivities: nil)
    }

    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}
