import Foundation
import CommonCrypto
import Compression

// MARK: - Lectura little-endian sobre Data

extension Data {
    func u16(_ offset: Int) -> UInt16 {
        let b = startIndex + offset
        let lo = UInt16(self[b])
        let hi = UInt16(self[b + 1]) << 8
        return lo | hi
    }

    func u32(_ offset: Int) -> UInt32 {
        let b = startIndex + offset
        var v = UInt32(self[b])
        v |= UInt32(self[b + 1]) << 8
        v |= UInt32(self[b + 2]) << 16
        v |= UInt32(self[b + 3]) << 24
        return v
    }

    mutating func setU32(_ offset: Int, _ value: UInt32) {
        let b = startIndex + offset
        self[b] = UInt8(value & 0xFF)
        self[b + 1] = UInt8((value >> 8) & 0xFF)
        self[b + 2] = UInt8((value >> 16) & 0xFF)
        self[b + 3] = UInt8((value >> 24) & 0xFF)
    }

    mutating func setU24(_ offset: Int, _ value: UInt32) {
        let b = startIndex + offset
        self[b] = UInt8(value & 0xFF)
        self[b + 1] = UInt8((value >> 8) & 0xFF)
        self[b + 2] = UInt8((value >> 16) & 0xFF)
    }
}

// MARK: - AES de GTA V (AES-256 ECB repetido 16 veces, solo bloques completos)

enum GTAAES {
    static func transform(_ data: Data, key: Data, encrypt: Bool) throws -> Data {
        guard key.count == 32 else { throw RPFError.badKey }
        let blockBytes = (data.count / 16) * 16
        if blockBytes == 0 { return data }

        var head = [UInt8](data.prefix(blockBytes))
        let tail = data.suffix(data.count - blockBytes)
        let op = CCOperation(encrypt ? kCCEncrypt : kCCDecrypt)
        var ok = true

        head.withUnsafeMutableBytes { buf in
            key.withUnsafeBytes { k in
                for _ in 0..<16 {
                    var moved = 0
                    let status = CCCrypt(
                        op,
                        CCAlgorithm(kCCAlgorithmAES),
                        CCOptions(kCCOptionECBMode),
                        k.baseAddress, 32,
                        nil,
                        buf.baseAddress, blockBytes,
                        buf.baseAddress, blockBytes,
                        &moved
                    )
                    if status != Int32(kCCSuccess) { ok = false; return }
                }
            }
        }
        if !ok { throw RPFError.badKey }

        var out = Data(head)
        out.append(tail)
        return out
    }

    static func decrypt(_ data: Data, key: Data) throws -> Data {
        try transform(data, key: key, encrypt: false)
    }

    static func encrypt(_ data: Data, key: Data) throws -> Data {
        try transform(data, key: key, encrypt: true)
    }
}

// MARK: - Deflate crudo (el COMPRESSION_ZLIB de Apple es DEFLATE sin cabecera)

enum Deflate {
    static func inflate(_ data: Data, expectedSize: Int) throws -> Data {
        guard expectedSize > 0 else { return Data() }
        var output = Data(count: expectedSize)
        let written: Int = output.withUnsafeMutableBytes { dst in
            data.withUnsafeBytes { src in
                guard let d = dst.bindMemory(to: UInt8.self).baseAddress,
                      let s = src.bindMemory(to: UInt8.self).baseAddress else { return 0 }
                return compression_decode_buffer(d, expectedSize, s, data.count, nil, COMPRESSION_ZLIB)
            }
        }
        guard written > 0 else { throw RPFError.decompressFailed }
        if written < expectedSize { output.removeSubrange(written..<expectedSize) }
        return output
    }
}

// MARK: - Errores

enum RPFError: LocalizedError {
    case notRPF7
    case truncated
    case needsKey
    case badKey
    case unsupportedEncryption(String)
    case decompressFailed
    case readOnly
    case unsupported(String)
    case io(String)

    var errorDescription: String? {
        switch self {
        case .notRPF7:
            return "El archivo no es un RPF7 (formato de GTA V / RDR2 PC)."
        case .truncated:
            return "El archivo está incompleto o dañado."
        case .needsKey:
            return "Este archivo está cifrado con AES. Importá la clave AES (32 bytes) desde Ajustes."
        case .badKey:
            return "La clave AES no es válida (debe tener 32 bytes)."
        case .unsupportedEncryption(let what):
            return "Cifrado no soportado todavía: \(what)."
        case .decompressFailed:
            return "No se pudo descomprimir el contenido."
        case .readOnly:
            return "No hay permiso de escritura sobre este archivo. Copialo a la carpeta de la app y abrilo desde ahí."
        case .unsupported(let what):
            return what
        case .io(let msg):
            return msg
        }
    }
}
