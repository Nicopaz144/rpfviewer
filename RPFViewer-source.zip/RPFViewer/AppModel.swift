import SwiftUI
import UniformTypeIdentifiers

/// Estado global de la app: archivo abierto, clave AES y errores.
@MainActor
final class AppModel: ObservableObject {
    @Published var archive: RPFArchive?
    @Published var archiveName = ""
    @Published var errorMessage: String?
    @Published var hasKey = false
    @Published var revision = 0   // se incrementa al modificar el archivo para refrescar la lista

    private var scopedURL: URL?

    private static var keyURL: URL {
        let dir = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir.appendingPathComponent("aes.key")
    }

    init() {
        hasKey = loadKey() != nil
    }

    // MARK: Clave AES

    func loadKey() -> Data? {
        guard let d = try? Data(contentsOf: Self.keyURL), d.count == 32 else { return nil }
        return d
    }

    /// Acepta 32 bytes crudos o 64 caracteres hexadecimales en texto.
    func importKey(from url: URL) {
        let access = url.startAccessingSecurityScopedResource()
        defer { if access { url.stopAccessingSecurityScopedResource() } }
        do {
            let raw = try Data(contentsOf: url)
            var key: Data?
            if raw.count == 32 {
                key = raw
            } else if let text = String(data: raw, encoding: .utf8) {
                key = Self.parseHex(text)
            }
            guard let k = key, k.count == 32 else {
                errorMessage = "La clave debe ser un archivo de 32 bytes o un texto con 64 caracteres hexadecimales."
                return
            }
            try k.write(to: Self.keyURL, options: .atomic)
            hasKey = true
        } catch {
            errorMessage = "No se pudo importar la clave: \(error.localizedDescription)"
        }
    }

    func removeKey() {
        try? FileManager.default.removeItem(at: Self.keyURL)
        hasKey = false
    }

    private static func parseHex(_ text: String) -> Data? {
        let cleaned = text.filter { $0.isHexDigit }
        guard cleaned.count == 64 else { return nil }
        var out = Data()
        var idx = cleaned.startIndex
        while idx < cleaned.endIndex {
            let next = cleaned.index(idx, offsetBy: 2)
            guard let byte = UInt8(cleaned[idx..<next], radix: 16) else { return nil }
            out.append(byte)
            idx = next
        }
        return out
    }

    // MARK: Abrir / cerrar

    func open(url: URL) {
        close()
        let access = url.startAccessingSecurityScopedResource()
        if access { scopedURL = url }
        do {
            archive = try RPFArchive(url: url, key: loadKey(), wantsWrite: true)
            archiveName = url.lastPathComponent
        } catch {
            if access { url.stopAccessingSecurityScopedResource() }
            scopedURL = nil
            errorMessage = error.localizedDescription
        }
    }

    func close() {
        archive = nil
        archiveName = ""
        if let u = scopedURL {
            u.stopAccessingSecurityScopedResource()
            scopedURL = nil
        }
    }

    // MARK: Operaciones

    func export(_ entry: RPFEntry) -> URL? {
        guard let archive = archive else { return nil }
        do {
            let data = try archive.extract(entry)
            let dir = FileManager.default.temporaryDirectory.appendingPathComponent("export", isDirectory: true)
            try FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
            let out = dir.appendingPathComponent(entry.name)
            try data.write(to: out, options: .atomic)
            return out
        } catch {
            errorMessage = error.localizedDescription
            return nil
        }
    }

    func undoLast() {
        guard let archive = archive else { return }
        do {
            try archive.undoLast()
            revision += 1
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func restoreOriginal() {
        guard let archive = archive else { return }
        do {
            try archive.restoreOriginal()
            revision += 1
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func replace(_ entry: RPFEntry, with url: URL) {
        guard let archive = archive else { return }
        let access = url.startAccessingSecurityScopedResource()
        defer { if access { url.stopAccessingSecurityScopedResource() } }
        do {
            let data = try Data(contentsOf: url)
            try archive.replace(entry, with: data)
            revision += 1
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}
