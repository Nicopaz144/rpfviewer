import Foundation

// Formato RPF7 (GTA V / RDR2 en PC).
//
// Cabecera (16 bytes, little-endian):
//   u32 version      = 0x52504637
//   u32 entryCount
//   u32 namesLength
//   u32 encryption   = 0 / 0x4E45504F (sin cifrar), 0x0FFFFFF9 (AES), 0x0FEFFFFF (NG)
// Luego: entryCount * 16 bytes de entradas y namesLength bytes de nombres.
//
// Entrada (16 bytes), se lee como dos u32: y (bytes 0-3) y x (bytes 4-7)
//   x == 0x7FFFFF00      -> carpeta:  u32 nameOffset, u32 marca, u32 childIndex, u32 childCount
//   bit 31 de x == 0     -> binario:  nameOffset(16) fileSize(24) fileOffset(24, en bloques de 512)
//                                     u32 uncompressedSize, u32 isEncrypted
//   bit 31 de x == 1     -> recurso:  nameOffset(16) fileSize(24) fileOffset(23)
//                                     u32 systemFlags, u32 graphicsFlags

enum RPFEncryption: Equatable {
    case plain
    case aes
    case ng
    case unknown(UInt32)

    init(raw: UInt32) {
        switch raw {
        case 0, 0x4E45504F: self = .plain
        case 0x0FFFFFF9: self = .aes
        case 0x0FEFFFFF: self = .ng
        default: self = .unknown(raw)
        }
    }

    var label: String {
        switch self {
        case .plain: return "Sin cifrar"
        case .aes: return "AES"
        case .ng: return "NG"
        case .unknown(let v): return String(format: "Desconocido (0x%08X)", v)
        }
    }
}

enum RPFKind {
    case directory
    case binary
    case resource
}

struct RPFEntry: Identifiable, Hashable {
    let id: Int
    let kind: RPFKind
    let name: String
    var childIndex = 0
    var childCount = 0
    var fileOffsetBlocks: UInt32 = 0
    var fileSize: UInt32 = 0
    var uncompressedSize: UInt32 = 0
    var isEncrypted = false
    var systemFlags: UInt32 = 0
    var graphicsFlags: UInt32 = 0

    var isDirectory: Bool { kind == .directory }
    var isNestedArchive: Bool { name.lowercased().hasSuffix(".rpf") }

    /// Tamaño lógico para mostrar en la lista.
    var displaySize: Int {
        switch kind {
        case .directory: return childCount
        case .binary: return Int(uncompressedSize)
        case .resource: return Int(fileSize)
        }
    }

    var isCompressed: Bool { kind == .binary && fileSize > 0 }
}

final class RPFArchive {
    let url: URL
    let encryption: RPFEncryption
    private(set) var entries: [RPFEntry] = []
    private(set) var isWritable: Bool

    private let handle: FileHandle
    private let key: Data?
    private var rawEntries: Data

    // MARK: Apertura

    init(url: URL, key: Data?, wantsWrite: Bool) throws {
        var h: FileHandle?
        var writable = false
        if wantsWrite, let upd = try? FileHandle(forUpdating: url) {
            h = upd
            writable = true
        }
        if h == nil {
            do {
                h = try FileHandle(forReadingFrom: url)
            } catch {
                throw RPFError.io("No se pudo abrir el archivo: \(error.localizedDescription)")
            }
        }
        guard let handle = h else { throw RPFError.io("No se pudo abrir el archivo.") }

        self.url = url
        self.handle = handle
        self.isWritable = writable
        self.key = key

        // Cabecera
        try handle.seek(toOffset: 0)
        guard let header = try handle.read(upToCount: 16), header.count == 16 else {
            throw RPFError.notRPF7
        }
        guard header.u32(0) == 0x52504637 else { throw RPFError.notRPF7 }

        let entryCount = Int(header.u32(4))
        let namesLength = Int(header.u32(8))
        let enc = RPFEncryption(raw: header.u32(12))
        self.encryption = enc

        guard entryCount > 0, entryCount < 2_000_000, namesLength >= 0, namesLength < 128 * 1024 * 1024 else {
            throw RPFError.truncated
        }

        // Tabla de contenidos
        guard var entriesData = try handle.read(upToCount: entryCount * 16), entriesData.count == entryCount * 16 else {
            throw RPFError.truncated
        }
        guard var namesData = try handle.read(upToCount: namesLength), namesData.count == namesLength else {
            throw RPFError.truncated
        }

        switch enc {
        case .plain:
            break
        case .aes:
            guard let key = key else { throw RPFError.needsKey }
            entriesData = try GTAAES.decrypt(entriesData, key: key)
            namesData = try GTAAES.decrypt(namesData, key: key)
        case .ng:
            throw RPFError.unsupportedEncryption("este RPF usa cifrado NG en la tabla de contenidos")
        case .unknown(let v):
            throw RPFError.unsupportedEncryption(String(format: "tipo 0x%08X", v))
        }

        self.rawEntries = entriesData
        self.entries = RPFArchive.parseEntries(entriesData, names: namesData, count: entryCount)
    }

    deinit {
        try? handle.close()
    }

    // MARK: Parseo

    private static func parseEntries(_ data: Data, names: Data, count: Int) -> [RPFEntry] {
        var result: [RPFEntry] = []
        result.reserveCapacity(count)

        for i in 0..<count {
            let o = i * 16
            let y = data.u32(o)
            let x = data.u32(o + 4)

            if x == 0x7FFFFF00 {
                var e = RPFEntry(id: i, kind: .directory, name: cString(names, at: Int(y)))
                e.childIndex = Int(data.u32(o + 8))
                e.childCount = Int(data.u32(o + 12))
                result.append(e)
            } else {
                let nameOffset = Int(y & 0xFFFF)
                let sizeLow = y >> 16
                let sizeHigh = x & 0xFF
                let size = sizeLow | (sizeHigh << 16)
                let name = cString(names, at: nameOffset)

                if (x & 0x8000_0000) == 0 {
                    var e = RPFEntry(id: i, kind: .binary, name: name)
                    e.fileSize = size
                    e.fileOffsetBlocks = x >> 8
                    e.uncompressedSize = data.u32(o + 8)
                    e.isEncrypted = data.u32(o + 12) == 1
                    result.append(e)
                } else {
                    var e = RPFEntry(id: i, kind: .resource, name: name)
                    e.fileSize = size
                    e.fileOffsetBlocks = (x >> 8) & 0x7FFFFF
                    e.systemFlags = data.u32(o + 8)
                    e.graphicsFlags = data.u32(o + 12)
                    // CodeWalker marca los .ysc como cifrados.
                    e.isEncrypted = name.lowercased().hasSuffix(".ysc")
                    result.append(e)
                }
            }
        }
        return result
    }

    private static func cString(_ names: Data, at offset: Int) -> String {
        guard offset >= 0, offset < names.count else { return "" }
        let start = names.startIndex + offset
        var end = start
        while end < names.endIndex && names[end] != 0 { end += 1 }
        return String(decoding: names[start..<end], as: UTF8.self)
    }

    // MARK: Navegación

    var root: RPFEntry { entries[0] }

    func children(of dir: RPFEntry) -> [RPFEntry] {
        guard dir.kind == .directory else { return [] }
        let start = dir.childIndex
        let end = min(start + dir.childCount, entries.count)
        guard start >= 0, start < end else { return [] }
        return Array(entries[start..<end])
    }

    // MARK: Lectura

    private func read(at offset: UInt64, count: Int) throws -> Data {
        guard count >= 0 else { throw RPFError.truncated }
        if count == 0 { return Data() }
        try handle.seek(toOffset: offset)
        guard let d = try handle.read(upToCount: count), d.count == count else {
            throw RPFError.truncated
        }
        return d
    }

    private func decryptFileData(_ data: Data) throws -> Data {
        switch encryption {
        case .aes:
            guard let key = key else { throw RPFError.needsKey }
            return try GTAAES.decrypt(data, key: key)
        default:
            throw RPFError.unsupportedEncryption("este archivo usa cifrado NG (clave derivada del nombre)")
        }
    }

    /// Binarios: contenido ya descifrado y descomprimido.
    /// Recursos: bytes tal como están guardados en el RPF (incluye la cabecera de 16 bytes).
    func extract(_ e: RPFEntry) throws -> Data {
        let offset = UInt64(e.fileOffsetBlocks) * 512
        switch e.kind {
        case .directory:
            throw RPFError.unsupported("Es una carpeta, no un archivo.")

        case .binary:
            let storedSize = e.fileSize == 0 ? Int(e.uncompressedSize) : Int(e.fileSize)
            var data = try read(at: offset, count: storedSize)
            if e.isEncrypted { data = try decryptFileData(data) }
            if e.fileSize > 0 {
                data = try Deflate.inflate(data, expectedSize: Int(e.uncompressedSize))
            }
            return data

        case .resource:
            if e.fileSize == 0xFFFFFF {
                throw RPFError.unsupported("Este recurso es demasiado grande para exportarlo en crudo.")
            }
            return try read(at: offset, count: Int(e.fileSize))
        }
    }

    // MARK: Escritura

    /// Reemplaza un archivo binario agregando el contenido nuevo al final del RPF
    /// y apuntando la entrada hacia él. El contenido viejo queda como espacio sin usar.
    func replace(_ e: RPFEntry, with newData: Data) throws {
        guard isWritable else { throw RPFError.readOnly }
        guard e.kind == .binary else {
            throw RPFError.unsupported("Por ahora solo se pueden reemplazar archivos binarios, no recursos (.ydr, .ytd, etc.).")
        }
        guard newData.count < Int(UInt32.max) else {
            throw RPFError.unsupported("El archivo nuevo es demasiado grande.")
        }

        let end = try handle.seekToEnd()
        let aligned = (end + 511) / 512 * 512
        let block = aligned / 512
        guard block <= 0x7FFFFF else {
            throw RPFError.unsupported("El RPF es demasiado grande para agregar más datos.")
        }

        // 1) Datos nuevos al final, alineados a 512 bytes.
        try handle.seek(toOffset: end)
        if aligned > end {
            try handle.write(contentsOf: Data(count: Int(aligned - end)))
        }
        try handle.write(contentsOf: newData)
        let pad = (512 - newData.count % 512) % 512
        if pad > 0 { try handle.write(contentsOf: Data(count: pad)) }

        // 2) Actualizar la entrada: sin comprimir, sin cifrar.
        var raw = rawEntries
        let o = e.id * 16
        raw.setU24(o + 2, 0)
        raw.setU24(o + 5, UInt32(block))
        raw.setU32(o + 8, UInt32(newData.count))
        raw.setU32(o + 12, 0)

        // 3) Escribir la tabla (punto de confirmación).
        try writeTOC(raw)
        rawEntries = raw

        var updated = e
        updated.fileSize = 0
        updated.fileOffsetBlocks = UInt32(block)
        updated.uncompressedSize = UInt32(newData.count)
        updated.isEncrypted = false
        entries[e.id] = updated
    }

    private func writeTOC(_ plain: Data) throws {
        var out = plain
        if encryption == .aes {
            guard let key = key else { throw RPFError.needsKey }
            out = try GTAAES.encrypt(plain, key: key)
        }
        try handle.seek(toOffset: 16)
        try handle.write(contentsOf: out)
        try handle.synchronize()
    }
}
